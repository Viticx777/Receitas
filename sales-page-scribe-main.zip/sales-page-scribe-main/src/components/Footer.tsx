
import React from "react";
import { Instagram, Facebook, Twitter, Mail, Phone } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-chocolate-dark text-cream-light py-12 px-4">
      <div className="container mx-auto">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="text-xl font-bold text-cream mb-4">Receitas Perfeitas</h3>
            <p className="mb-4">
              Transformando pessoas comuns em confeiteiros extraordinários através de nossos e-books e cursos online.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="hover:text-caramel transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="hover:text-caramel transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="hover:text-caramel transition-colors">
                <Twitter size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-bold text-cream mb-4">Links Rápidos</h3>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-caramel transition-colors">Sobre Nós</a></li>
              <li><a href="#" className="hover:text-caramel transition-colors">Blog de Receitas</a></li>
              <li><a href="#" className="hover:text-caramel transition-colors">Cursos Online</a></li>
              <li><a href="#" className="hover:text-caramel transition-colors">Política de Privacidade</a></li>
              <li><a href="#" className="hover:text-caramel transition-colors">Termos de Uso</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold text-cream mb-4">Contato</h3>
            <ul className="space-y-2">
              <li className="flex items-center">
                <Mail size={16} className="mr-2" />
                <a href="mailto:contato@receitasperfeitas.com" className="hover:text-caramel transition-colors">contato@receitasperfeitas.com</a>
              </li>
              <li className="flex items-center">
                <Phone size={16} className="mr-2" />
                <a href="tel:+5511999999999" className="hover:text-caramel transition-colors">(11) 99999-9999</a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold text-cream mb-4">Newsletter</h3>
            <p className="mb-3">Receba nossas dicas e receitas gratuitas semanalmente</p>
            <div className="flex">
              <input
                type="email"
                placeholder="Seu e-mail"
                className="px-4 py-2 rounded-l-lg flex-grow"
              />
              <button className="bg-caramel hover:bg-caramel-light text-white px-4 py-2 rounded-r-lg">
                Inscrever
              </button>
            </div>
          </div>
        </div>
        
        <div className="border-t border-chocolate pt-6">
          <div className="flex flex-col md:flex-row md:justify-between items-center">
            <p>&copy; {new Date().getFullYear()} Receitas Perfeitas. Todos os direitos reservados.</p>
            <div className="mt-4 md:mt-0 flex items-center space-x-4">
              <a href="mailto:info@bolosperfeitos.com.br" className="hover:text-caramel transition-colors flex items-center">
                <Mail size={18} className="mr-2" />
                <span>info@bolosperfeitos.com.br</span>
              </a>
              <a href="tel:+5521987654321" className="hover:text-caramel transition-colors flex items-center">
                <Phone size={18} className="mr-2" />
                <span>(21) 98765-4321</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
