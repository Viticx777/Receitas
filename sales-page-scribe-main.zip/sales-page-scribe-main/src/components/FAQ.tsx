
import React, { useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";

interface FAQItemProps {
  question: string;
  answer: string;
  isOpen: boolean;
  onClick: () => void;
}

const FAQItem: React.FC<FAQItemProps> = ({ question, answer, isOpen, onClick }) => {
  return (
    <div className="border-b border-caramel/20 last:border-0">
      <button
        className="flex justify-between items-center w-full py-4 text-left"
        onClick={onClick}
      >
        <span className="font-semibold text-chocolate">{question}</span>
        {isOpen ? (
          <ChevronUp className="text-caramel flex-shrink-0" size={20} />
        ) : (
          <ChevronDown className="text-caramel flex-shrink-0" size={20} />
        )}
      </button>
      <div
        className={`overflow-hidden transition-all duration-300 ${
          isOpen ? "max-h-96 pb-4" : "max-h-0"
        }`}
      >
        <p className="text-chocolate-light">{answer}</p>
      </div>
    </div>
  );
};

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  const faqs = [
    {
      question: "Quanto tempo terei acesso ao e-book?",
      answer: "Seu acesso é vitalício. Você poderá acessar o material a qualquer momento, de qualquer dispositivo, e também terá direito a todas as atualizações futuras sem custo adicional."
    },
    {
      question: "Preciso ter experiência prévia na cozinha?",
      answer: "Não é necessário ter experiência prévia. O e-book foi desenvolvido para atender tanto iniciantes quanto pessoas com alguma experiência, com instruções detalhadas passo a passo."
    },
    {
      question: "Quais formas de pagamento são aceitas?",
      answer: "Aceitamos cartões de crédito (parcelamos em até 5x sem juros), débito, PIX e boleto bancário. Todas as transações são processadas em ambiente seguro."
    },
    {
      question: "Como vou receber o material após a compra?",
      answer: "Após a confirmação do pagamento, você receberá um e-mail com as instruções de acesso ao e-book e ao grupo exclusivo. O processo é automático e o tempo máximo de envio é de 5 minutos."
    },
    {
      question: "As receitas são difíceis de fazer?",
      answer: "Não. Todas as receitas foram testadas pensando na facilidade de execução, com ingredientes comuns que podem ser encontrados em qualquer supermercado."
    },
    {
      question: "Posso solicitar o reembolso se não gostar?",
      answer: "Sim. Oferecemos garantia de satisfação de 7 dias. Se você não ficar satisfeito com o material, basta solicitar o reembolso dentro desse período e devolveremos 100% do seu investimento, sem questionamentos."
    }
  ];

  return (
    <section className="py-20 px-4 bg-cream">
      <div className="container mx-auto max-w-3xl">
        <h2 className="text-3xl md:text-4xl font-bold text-chocolate text-center mb-4">
          Ficou alguma dúvida?
        </h2>
        <p className="text-chocolate-light text-center mb-12">
          Confira as perguntas mais frequentes sobre o e-book
        </p>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          {faqs.map((faq, index) => (
            <FAQItem
              key={index}
              question={faq.question}
              answer={faq.answer}
              isOpen={openIndex === index}
              onClick={() => toggleFAQ(index)}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;
