
import React from "react";
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { Card, CardContent } from "@/components/ui/card";

const RecipeCard = ({ title, items, color, imageSrc }: { title: string, items: string[], color: string, imageSrc: string }) => {
  return (
    <Card className="overflow-hidden">
      <AspectRatio ratio={16/9} className="bg-muted">
        <img src={imageSrc} alt={title} className="object-cover w-full h-full" />
      </AspectRatio>
      <CardContent className={`${color} p-6`}>
        <h3 className="text-2xl font-bold text-cream mb-6 text-center">{title}</h3>
        <ul className="space-y-3 mb-6">
          {items.map((item, index) => (
            <li key={index} className="flex items-start">
              <Check className="text-caramel flex-shrink-0 mt-1 mr-2" size={18} />
              <span className="text-cream-light">{item}</span>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
};

const Conteudo = () => {
  const bolos = [
    "Bolo de Chocolate Tradicional",
    "Bolo de Cenoura com Cobertura",
    "Bolo Red Velvet",
    "Bolo de Limão",
    "Bolo de Manteiga",
    "Bolo de Festa Colorido"
  ];

  const coberturas = [
    "Ganache de Chocolate Meio Amargo",
    "Buttercream de Baunilha",
    "Cobertura de Cream Cheese",
    "Cobertura de Doce de Leite",
    "Glacê Real",
    "Chantilly Estabilizado"
  ];

  const especiais = [
    "Bolo Naked Cake",
    "Bolo Drip Cake",
    "Bolo de Casamento",
    "Bolo de Aniversário Temático",
    "Bolo Low Carb",
    "Bolo Vegano"
  ];

  return (
    <section id="conteudo" className="py-20 px-4 bg-cream">
      <div className="container mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-chocolate text-center mb-4">
          Conheça o conteúdo do nosso e-book
        </h2>
        <p className="text-chocolate-light text-center mb-12 max-w-2xl mx-auto">
          Mais de 10 receitas exclusivas, testadas e aprovadas por nossos especialistas
        </p>
        
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <RecipeCard 
            title="Bolos" 
            items={bolos} 
            color="bg-chocolate" 
            imageSrc="https://images.unsplash.com/photo-1578985545062-69928b1d9587?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1089&q=80"
          />
          <RecipeCard 
            title="Coberturas" 
            items={coberturas} 
            color="bg-chocolate-dark" 
            imageSrc="https://images.unsplash.com/photo-1542826438-bd32f43d626f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1292&q=80"
          />
          <RecipeCard 
            title="Especiais" 
            items={especiais} 
            color="bg-chocolate" 
            imageSrc="https://images.unsplash.com/photo-1535141192574-5d4897c12636?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=987&q=80"
          />
        </div>
        
        <div className="text-center">
          <Button 
            className="bg-success hover:bg-green-600 text-white font-bold py-4 px-8 rounded-lg text-lg transition-all transform hover:scale-105"
            onClick={() => window.location.href = "https://pay.cakto.com.br/38hwd4w_339086"}
          >
            QUERO GARANTIR MEU E-BOOK AGORA!
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Conteudo;
