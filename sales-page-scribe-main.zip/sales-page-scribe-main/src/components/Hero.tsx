
import React from "react";
import { Button } from "@/components/ui/button";
import { Check, Star } from "lucide-react";
import { 
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious
} from "@/components/ui/carousel";

const Hero = () => {
  return (
    <section className="bg-gradient-to-b from-cream to-cream-dark py-20 px-4">
      <div className="container mx-auto grid md:grid-cols-2 gap-12 items-center">
        <div>
          <h1 className="text-4xl md:text-5xl font-bold text-chocolate mb-6">
            Aprenda a Fazer Receitas de Bolo Perfeitas
          </h1>
          <p className="text-lg text-chocolate-light mb-8">
            Descubra os segredos para criar sobremesas irresistíveis que impressionam a todos. 
            Receitas testadas e aprovadas pelos melhores confeiteiros.
          </p>
          
          <div className="flex items-center mb-8">
            <div className="flex mr-3">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star key={star} className="text-caramel fill-caramel" size={20} />
              ))}
            </div>
            <span className="text-chocolate-light">Mais de 2.500 alunos satisfeitos</span>
          </div>
          
          <div className="space-y-3 mb-8">
            <div className="flex items-start">
              <Check className="text-success mr-2" size={20} />
              <p className="text-chocolate">Receitas detalhadas passo a passo</p>
            </div>
            <div className="flex items-start">
              <Check className="text-success mr-2" size={20} />
              <p className="text-chocolate">Dicas profissionais e truques especiais</p>
            </div>
            <div className="flex items-start">
              <Check className="text-success mr-2" size={20} />
              <p className="text-chocolate">Acesso vitalício às atualizações</p>
            </div>
          </div>
          
          <Button 
            id="cta-principal"
            className="bg-success hover:bg-green-600 text-white font-bold py-4 px-8 rounded-lg text-lg transition-all transform hover:scale-105"
            onClick={() => window.location.href = "https://pay.cakto.com.br/38hwd4w_339086"}
          >
            QUERO APRENDER AGORA!
          </Button>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-xl border border-caramel/30 transform md:rotate-3 hover:rotate-0 transition-transform duration-300">
          <Carousel opts={{ loop: true }} className="w-full max-w-lg mx-auto">
            <CarouselContent>
              <CarouselItem>
                <div className="aspect-w-1 aspect-h-1 rounded-lg overflow-hidden mb-4">
                  <img 
                    src="https://images.unsplash.com/photo-1588195538326-c5b1e9f80a1b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1050&q=80" 
                    alt="Delicious cake" 
                    className="object-cover w-full h-full"
                  />
                </div>
              </CarouselItem>
              <CarouselItem>
                <div className="aspect-w-1 aspect-h-1 rounded-lg overflow-hidden mb-4">
                  <img 
                    src="https://images.unsplash.com/photo-1562440499-64c9a111f713?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80" 
                    alt="Beautiful cake" 
                    className="object-cover w-full h-full"
                  />
                </div>
              </CarouselItem>
              <CarouselItem>
                <div className="aspect-w-1 aspect-h-1 rounded-lg overflow-hidden mb-4">
                  <img 
                    src="https://images.unsplash.com/photo-1563729784474-d77dbb933a9e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80" 
                    alt="Elegant cake" 
                    className="object-cover w-full h-full"
                  />
                </div>
              </CarouselItem>
            </CarouselContent>
            <CarouselPrevious className="hidden md:flex" />
            <CarouselNext className="hidden md:flex" />
          </Carousel>

          <div className="bg-chocolate rounded-lg p-6 text-center text-cream mt-4">
            <div className="flex flex-col justify-center items-center h-full">
              <h3 className="text-2xl font-bold mb-4">E-book Completo</h3>
              <p className="text-lg mb-6">Receitas de Bolo e muito mais!</p>
              <div className="w-32 h-32 bg-caramel rounded-full flex items-center justify-center mb-6">
                <span className="text-white text-5xl font-bold">10+</span>
              </div>
              <p className="text-lg">Receitas exclusivas</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
