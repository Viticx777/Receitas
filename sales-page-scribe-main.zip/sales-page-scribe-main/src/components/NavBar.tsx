
import React from "react";
import { Button } from "@/components/ui/button";
import { ArrowDown } from "lucide-react";

const NavBar = () => {
  return (
    <nav className="bg-chocolate sticky top-0 z-50 shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <h1 className="text-cream-light text-xl font-bold">Receitas Perfeitas</h1>
        </div>
        <div className="hidden md:flex space-x-6 text-cream-light">
          <a href="#beneficios" className="hover:text-caramel transition-colors duration-200">Benefícios</a>
          <a href="#conteudo" className="hover:text-caramel transition-colors duration-200">Conteúdo</a>
          <a href="#depoimentos" className="hover:text-caramel transition-colors duration-200">Depoimentos</a>
          <a href="#preco" className="hover:text-caramel transition-colors duration-200">Preço</a>
        </div>
        <Button 
          className="bg-caramel hover:bg-caramel-light text-white font-bold flex items-center gap-2"
          onClick={() => window.location.href = "https://pay.cakto.com.br/38hwd4w_339086"}
        >
          Garantir Acesso <ArrowDown size={16} />
        </Button>
      </div>
    </nav>
  );
};

export default NavBar;
