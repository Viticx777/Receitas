
import React from "react";
import { Download, Book, MessageSquare, Award, ChefHat, ShoppingCart } from "lucide-react";

const StepCard = ({ number, icon, title, description }: { number: number, icon: React.ReactNode, title: string, description: string }) => {
  return (
    <div className="flex gap-4 p-5 border border-caramel/30 rounded-lg shadow-sm hover:shadow-md transition-shadow bg-cream">
      <div className="flex-shrink-0 bg-caramel w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-xl">
        {number}
      </div>
      <div>
        <div className="flex items-center gap-2 mb-2">
          {icon}
          <h3 className="font-bold text-lg text-chocolate">{title}</h3>
        </div>
        <p className="text-chocolate-light">{description}</p>
      </div>
    </div>
  );
};

const ComoFunciona = () => {
  const steps = [
    {
      icon: <ShoppingCart size={20} className="text-caramel" />,
      title: "Faça o pedido",
      description: "Escolha a forma de pagamento e complete a compra com segurança."
    },
    {
      icon: <Download size={20} className="text-caramel" />,
      title: "Receba o acesso",
      description: "O e-book será enviado para seu e-mail em até 5 minutos após a confirmação do pagamento."
    },
    {
      icon: <Book size={20} className="text-caramel" />,
      title: "Estude o material",
      description: "Explore o conteúdo no seu próprio ritmo, em qualquer dispositivo."
    },
    {
      icon: <MessageSquare size={20} className="text-caramel" />,
      title: "Tire suas dúvidas",
      description: "Acesso ao grupo exclusivo para esclarecer dúvidas com nossos especialistas."
    },
    {
      icon: <ChefHat size={20} className="text-caramel" />,
      title: "Prepare as receitas",
      description: "Siga as instruções passo a passo e surpreenda com os resultados."
    },
    {
      icon: <Award size={20} className="text-caramel" />,
      title: "Compartilhe o sucesso",
      description: "Mostre suas criações e receba feedbacks dos outros participantes."
    }
  ];

  return (
    <section className="py-20 px-4 bg-cream-dark">
      <div className="container mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-chocolate text-center mb-4">
          Como o E-book vai te ajudar?
        </h2>
        <p className="text-chocolate-light text-center mb-12 max-w-2xl mx-auto">
          Um processo simples para você transformar sua relação com a confeitaria
        </p>
        
        <div className="grid md:grid-cols-2 gap-6">
          {steps.map((step, index) => (
            <StepCard 
              key={index}
              number={index + 1}
              icon={step.icon}
              title={step.title}
              description={step.description}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ComoFunciona;
