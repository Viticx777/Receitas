
import React from "react";
import { BookOpen, Clock, Award, ThumbsUp } from "lucide-react";

const BenefitCard = ({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) => {
  return (
    <div className="bg-chocolate p-6 rounded-lg shadow-md transition-transform duration-300 hover:transform hover:scale-105">
      <div className="flex items-center mb-4">
        <div className="bg-caramel p-3 rounded-full mr-4">
          {icon}
        </div>
        <h3 className="text-xl font-bold text-cream">{title}</h3>
      </div>
      <p className="text-cream-light">{description}</p>
    </div>
  );
};

const Beneficios = () => {
  const benefits = [
    {
      icon: <BookOpen className="text-white" size={24} />,
      title: "Fácil de seguir",
      description: "Receitas com linguagem simples e explicações detalhadas para você não ter dúvidas."
    },
    {
      icon: <Clock className="text-white" size={24} />,
      title: "Economize tempo",
      description: "Técnicas testadas que reduzem erros e garantem resultados perfeitos na primeira tentativa."
    },
    {
      icon: <Award className="text-white" size={24} />,
      title: "Qualidade profissional",
      description: "Aprenda técnicas utilizadas por confeiteiros premiados para elevar suas sobremesas."
    },
    {
      icon: <ThumbsUp className="text-white" size={24} />,
      title: "Satisfação garantida",
      description: "Se não ficar satisfeito nos primeiros 7 dias, devolvemos seu investimento integralmente."
    }
  ];

  return (
    <section id="beneficios" className="py-20 px-4 bg-cream">
      <div className="container mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-chocolate text-center mb-4">
          O E-book é para aqueles que são:
        </h2>
        <p className="text-chocolate-light text-center mb-12 max-w-2xl mx-auto">
          Descubra como nosso e-book vai transformar sua experiência na cozinha e fazer você 
          criar sobremesas dignas de vitrine
        </p>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {benefits.map((benefit, index) => (
            <BenefitCard 
              key={index}
              icon={benefit.icon}
              title={benefit.title}
              description={benefit.description}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Beneficios;
