
import React from "react";
import { Star, Quote } from "lucide-react";

const TestimonialCard = ({ content, author, rating, isChat = false }: { content: string, author: string, rating: number, isChat?: boolean }) => {
  return (
    <div className={`bg-white p-6 rounded-lg shadow-md border border-caramel/20 ${isChat ? "flex flex-col" : ""}`}>
      <div className="flex mb-4">
        {Array.from({ length: rating }).map((_, index) => (
          <Star key={index} className="text-caramel fill-caramel" size={18} />
        ))}
      </div>
      <div className="relative">
        <Quote className="absolute top-0 left-0 text-caramel opacity-20" size={40} />
        <p className="text-chocolate-light mb-4 pl-8 pt-2">{content}</p>
      </div>
      <p className="font-bold text-chocolate">{author}</p>
    </div>
  );
};

const Depoimentos = () => {
  const testimonials = [
    {
      content: "Simplesmente amei! Nunca fui muito de cozinhar, mas com esse e-book ficou tudo tão fácil que agora faço questão de preparar as refeições em casa.",
      author: "Johnny Doe",
      rating: 5
    },
    {
      content: "Achei o e-book bonito e organizado, mas algumas receitas não funcionaram tão bem pra mim. Talvez eu tenha feito algo errado, mas esperava resultados melhores.",
      author: "Kleber rlk",
      rating: 3
    },
    {
      content: "Comprei o e-book e fiquei impressionada com a praticidade das receitas! Já testei várias e todas deram super certo. Salvou meus dias corridos na cozinha.",
      author: "Clara",
      rating: 5
    }
  ];

  return (
    <section id="depoimentos" className="py-20 px-4 bg-cream-dark">
      <div className="container mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-chocolate text-center mb-4">
          Depoimentos e Avaliações
        </h2>
        <p className="text-chocolate-light text-center mb-12 max-w-2xl mx-auto">
          Veja o que nossos alunos estão dizendo sobre o e-book de receitas
        </p>
        
        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <TestimonialCard 
              key={index}
              content={testimonial.content}
              author={testimonial.author}
              rating={testimonial.rating}
              isChat={true}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Depoimentos;
