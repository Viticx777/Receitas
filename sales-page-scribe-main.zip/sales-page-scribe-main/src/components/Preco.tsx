
import React from "react";
import { Button } from "@/components/ui/button";
import { Check, Lock } from "lucide-react";

const Preco = () => {
  return (
    <section id="preco" className="py-20 px-4 bg-chocolate">
      <div className="container mx-auto grid md:grid-cols-2 gap-12 items-center">
        <div>
          <h2 className="text-3xl md:text-4xl font-bold text-cream mb-6">
            Tudo o que você terá acesso:
          </h2>
          
          <div className="space-y-4 mb-8">
            <div className="flex items-start">
              <Check className="text-success mr-3 mt-1" size={22} />
              <div>
                <p className="text-cream text-lg font-semibold">E-book completo com +10 receitas de bolo exclusivas</p>
                <p className="text-cream-light">Receitas detalhadas com fotos e dicas especiais.</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <Check className="text-success mr-3 mt-1" size={22} />
              <div>
                <p className="text-cream text-lg font-semibold">Grupo exclusivo no WhatsApp</p>
                <p className="text-cream-light">Tire dúvidas diretamente com nossos especialistas.</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <Check className="text-success mr-3 mt-1" size={22} />
              <div>
                <p className="text-cream text-lg font-semibold">Vídeos complementares</p>
                <p className="text-cream-light">Demonstrações das técnicas mais importantes.</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <Check className="text-success mr-3 mt-1" size={22} />
              <div>
                <p className="text-cream text-lg font-semibold">Planilha de custos</p>
                <p className="text-cream-light">Calcule o custo real de cada receita facilmente.</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <Check className="text-success mr-3 mt-1" size={22} />
              <div>
                <p className="text-cream text-lg font-semibold">Acesso vitalício</p>
                <p className="text-cream-light">Incluindo todas as atualizações futuras.</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <Check className="text-success mr-3 mt-1" size={22} />
              <div>
                <p className="text-cream text-lg font-semibold">Bônus: 10 receitas de coberturas para bolo</p>
                <p className="text-cream-light">Complementos perfeitos para suas sobremesas.</p>
              </div>
            </div>
          </div>
          
          <div className="bg-cream-dark rounded-lg overflow-hidden mt-8 hidden md:block">
            <img 
              src="https://images.unsplash.com/photo-1464349095431-e9a21285b5c3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=936&q=80"
              alt="Delicious cakes being prepared"
              className="w-full h-64 object-cover"
            />
          </div>
        </div>
        
        <div className="bg-white p-8 rounded-lg shadow-xl">
          <div className="flex justify-center mb-6">
            <img 
              src="https://images.unsplash.com/photo-1565958011703-44f9829ba187?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=765&q=80"
              alt="Beautifully decorated cake"
              className="w-32 h-32 rounded-full object-cover border-4 border-cream"
            />
          </div>
          
          <div className="text-center mb-6">
            <p className="text-chocolate-light mb-2">Investimento único de</p>
            <div className="flex items-center justify-center gap-3 mb-2">
              <span className="text-chocolate-light line-through text-xl">R$ 97,00</span>
              <span className="bg-caramel text-white text-sm font-bold py-1 px-2 rounded">OFERTA</span>
            </div>
            <div className="text-chocolate font-bold">
              <span className="text-3xl">R$</span>
              <span className="text-6xl">27</span>
              <span className="text-3xl">,90</span>
            </div>
            <p className="text-chocolate-light mt-2">ou em até 5x de R$ 5,58</p>
          </div>
          
          <Button 
            className="w-full bg-success hover:bg-green-600 text-white font-bold py-4 px-8 rounded-lg text-lg mb-4"
            onClick={() => window.location.href = "https://pay.cakto.com.br/38hwd4w_339086"}
          >
            GARANTIR MEU ACESSO AGORA
          </Button>
          
          <div className="flex items-center justify-center text-chocolate-light mb-4">
            <Lock size={16} className="mr-2" />
            <span className="text-sm">Pagamento 100% seguro</span>
          </div>
          
          <div className="flex justify-center space-x-3">
            <img src="https://placekitten.com/40/25" alt="Visa" className="h-6 object-contain grayscale opacity-70" />
            <img src="https://placekitten.com/41/25" alt="Mastercard" className="h-6 object-contain grayscale opacity-70" />
            <img src="https://placekitten.com/42/25" alt="Elo" className="h-6 object-contain grayscale opacity-70" />
            <img src="https://placekitten.com/43/25" alt="Pix" className="h-6 object-contain grayscale opacity-70" />
            <img src="https://placekitten.com/44/25" alt="Boleto" className="h-6 object-contain grayscale opacity-70" />
          </div>
          
          <div className="mt-6 text-center">
            <p className="text-chocolate-light text-sm mb-2">Satisfação garantida ou seu dinheiro de volta</p>
            <p className="text-chocolate font-bold">7 dias de garantia incondicional</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Preco;
