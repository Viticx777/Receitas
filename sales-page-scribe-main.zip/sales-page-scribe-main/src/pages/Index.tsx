
import React from "react";
import NavBar from "@/components/NavBar";
import Hero from "@/components/Hero";
import Beneficios from "@/components/Beneficios";
import ComoFunciona from "@/components/ComoFunciona";
import Conteudo from "@/components/Conteudo";
import Depoimentos from "@/components/Depoimentos";
import Preco from "@/components/Preco";
import FAQ from "@/components/FAQ";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-cream">
      <NavBar />
      <Hero />
      <Beneficios />
      <ComoFunciona />
      <Conteudo />
      <Depoimentos />
      <Preco />
      <FAQ />
      <Footer />
    </div>
  );
};

export default Index;
